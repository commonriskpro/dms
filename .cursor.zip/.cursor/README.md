# Cursor Setup — DMS (Supercharged)

Drop this `.cursor/` folder into the root of the DMS repo.

## Agents
- coordinator.md (Orchestrator)
- architect.md
- backend-engineer.md
- frontend-engineer.md
- security-qa.md

## Skills
- backend-module-builder
- frontend-module-builder
- scaffold-module-spec-build
- performance-pass
- qa-hardening

## How to work (non-negotiable)
Use the strict 4-step flow:
1) Step 1 Spec (Architect) — no code
2) Step 2 Backend (Backend Engineer)
3) Step 3 Frontend (Frontend Engineer)
4) Step 4 Security & QA (Security & QA)

After EACH step, run Thin Gates: see `workflows/THIN_GATES.md`.

## Start here
Use `prompts/START_HERE.md` as your default prompt template.
