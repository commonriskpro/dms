# START HERE — Default Cursor Prompt (DMS Supercharged)

You are working in the DMS monorepo. Follow STRICTLY:
Step 1 Spec (Architect) → Step 2 Backend → Step 3 Frontend → Step 4 Security & QA.
Do not mix steps.

## Task
[Describe the feature/module in 1-2 sentences]

## Constraints (must follow)
- Multi-tenant: dealership_id on every business table; all queries scoped.
- RBAC: permission check on every route, before business logic.
- Zod at edge for all inputs.
- Pagination on all list endpoints (default 20, max 100).
- No PII in logs.
- Node 24.x / npm 11.x deterministic installs.
- Next caching safety: force-dynamic tenant APIs + noStore server pages.

## Required Deliverables each step
- File list of created/updated files
- Manual test checklist

## Proceed
1) Coordinator: produce a 4-step plan and hand Step 1 to Architect.
2) After Step 1, run Thin Gates.
3) Continue Step 2 → Thin Gates → Step 3 → Thin Gates → Step 4.
