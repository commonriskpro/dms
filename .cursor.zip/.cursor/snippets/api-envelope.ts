// Error envelope (reference)
// Success: { data: T }
// List: { data: T[], meta: { total, limit, offset } }
// Error: { error: { code: string, message: string, details?: unknown } }
