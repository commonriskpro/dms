// Tenant scoping rule (reference)
// Always resolve dealershipId from auth/session on server.
// Never accept dealershipId from request body.
// Every DB query must include dealershipId in where clause.
