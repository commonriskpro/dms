# 4-Step Flow Playbook

## Step 1 — Spec (Architect)
Outputs:
- Prisma schema changes (+ indexes/constraints)
- Route table + request/response contracts
- Zod schema definitions (names + shapes)
- RBAC matrix
- Events (emitted/consumed)
- Notes on audit coverage (create/update/delete + sensitive reads)

## Step 2 — Backend (Backend Engineer)
Outputs:
- Migrations
- DB layer (tenant-scoped)
- Services (RBAC enforced)
- API routes (Zod at edge + pagination)
- Tests (tenant isolation + RBAC negative + core positives)
- File list + manual test checklist

## Step 3 — Frontend (Frontend Engineer)
Outputs:
- Server-first pages + client components only for interactivity
- No fetch-on-mount for initial page data
- List/detail/forms with empty/loading/error states
- A11y basics (labels, keyboard)
- File list + manual test checklist

## Step 4 — Security & QA (Security & QA)
Outputs:
- Tenant isolation verification
- RBAC verification + abuse tests
- Rate limit checks (auth + sensitive)
- PII log hygiene
- Pagination verification
- QA checklist + what was fixed
