# Thin Gates (Run after every step)

## Gate A — Determinism
- [ ] Node is 24.x and npm is 11.x (packageManager pinned)
- [ ] No nested installs (no install scripts that run npm in subfolders)
- [ ] Lockfile is consistent; Vercel uses `npm ci`

## Gate B — Tenant safety
- [ ] Any tenant API route exports `dynamic = "force-dynamic"` (or route segment config)
- [ ] Any server page reading tenant/session data uses `noStore()`
- [ ] No cross-tenant caching; cache keys include dealership_id if used

## Gate C — API hygiene
- [ ] Zod validates params/query/body at the edge
- [ ] Error shape `{ error: { code, message, details? } }`
- [ ] List endpoints paginate + enforce max limit

## Gate D — RBAC
- [ ] Every route checks permission BEFORE business logic
- [ ] Negative tests exist for at least one denied case per protected action

## Gate E — Quality
- [ ] lint/build/tests pass for affected apps
- [ ] File list + manual test checklist provided
