# Pull Request Checklist (DMS)

## Scope
- [ ] This PR implements: [feature/module]
- [ ] Step completed: [1 Spec | 2 Backend | 3 Frontend | 4 Security & QA]

## Non-negotiables
- [ ] dealership_id scoping enforced
- [ ] RBAC checks before business logic
- [ ] Zod validation at edge
- [ ] Pagination + max limit enforced for lists
- [ ] No PII in logs
- [ ] force-dynamic + noStore where required
- [ ] Deterministic installs (npm ci) + lockfile clean

## Tests
- [ ] Unit/integration tests added/updated
- [ ] Tenant isolation tests added/updated
- [ ] RBAC negative tests added/updated
- [ ] lint/build/tests pass

## Manual test checklist (required)
1.
2.
3.

## Notes
- Risks:
- Follow-ups:
