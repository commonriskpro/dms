---
name: backend-module-builder
description: Builds backend modules with Prisma models, db layer, service layer, route handlers, audit logging, and tests. Use when building a new backend module, adding a backend feature, or when the user asks for backend module build steps, tenant-scoped API, or RBAC-protected endpoints.
---

# Backend Module Builder

Step-by-step guide to build a backend module in the DMS. Follow in order. Comply with DMS non-negotiables: multi-tenant (`dealership_id`), RBAC on all routes, Zod at the edge, pagination on lists, audit on create/update/delete and sensitive reads. No TODOs or placeholders.

**Deliverables**: Always return (1) a **file list** of created/updated files and (2) a **manual test checklist**.

---

## 1. Prisma models + indexes + constraints

- Add or extend schema (e.g. `prisma/schema.prisma` or under `modules/<name>/db`). Every business table **must** have `dealership_id` (UUID).
- Indexes:
  - `@@index([dealership_id])` for tenant lookups
  - Composite for common filters: `@@index([dealership_id, status])`, `@@index([dealership_id, created_at])`
  - Unique scoped by tenant: `@@unique([dealership_id, external_id])`
- Add foreign keys and constraints per spec. No raw card data; no SSN/DOB unless explicitly approved.

---

## 2. DB layer (scoped by dealership_id)

- Place under `modules/<module>/db`. All data access here; no raw Prisma in routes or services.
- Every function accepts `dealershipId` and uses it in every `where` clause. Never return or update another tenant's rows.
- Export: `getById`, `list` (with limit/offset or cursor), `create`, `update`, `delete` (or soft-delete) as needed. Use transactions for multi-step writes.

---

## 3. Service layer (transactions + RBAC)

- Place under `modules/<module>/service`. Services call db layer only; no direct Prisma.
- Use transactions for any multi-table or multi-step operation.
- RBAC: before create/update/delete and sensitive reads, check permission (e.g. permissions helper or role). Deny by default; no admin bypass unless required. Least privilege.
- Services accept `dealershipId`, `userId` (and optionally `role`/permissions) for scoping and audit.

---

## 4. Route handlers + Zod validation

- Place under `app/api/**`. Handlers are thin: validate → call service → respond.
- Validate **all** inputs with Zod at the edge: query, params, body. No unvalidated data to services. Error shape: `{ error: { code, message, details? } }`.
- Resolve `dealership_id` from auth/context; pass to service. Paginate all list endpoints (limit/offset or cursor).

---

## 5. Audit log (create/update/delete + sensitive reads)

- Write to the project audit mechanism for:
  - Create, update, delete on all critical resources
  - Sensitive reads where required (finance, customers, users/roles, documents)
- Record: who (user/id), what (resource/action), when (timestamp), tenant (`dealership_id`). Append-only; no updates or deletes of audit records.

---

## 6. Tests (tenant isolation + RBAC negative + core logic)

- Place under `modules/<module>/tests`.
- **Tenant isolation**: Assert dealership A never sees or changes dealership B data (get/list/update/delete with wrong tenant).
- **RBAC negative**: Assert unauthorized roles get denied; at least one denied case per protected action.
- **Core business logic**: Positive cases for main flows (create, update, list with filters, delete). Deterministic, fast.

---

## Completion: file list + manual test checklist

After implementing, always provide:

**File list**  
List every file created or updated (schema, db layer, service, routes, tests, shared types or Zod schemas).

**Manual test checklist**  
Short, actionable steps for a human (e.g. “As role X, create resource and confirm it appears only for same dealership”, “As role Y, attempt create and confirm 403”, “Verify audit log entry for delete”). Include at least one tenant-isolation check and one RBAC check.
