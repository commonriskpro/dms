---
name: performance-pass
description: Runs a performance pass on APIs: indexes for slow endpoints, N+1 elimination, safe server-side caching, smaller payloads, and list-endpoint limits. Use when the user asks for a performance pass, slow endpoint review, query optimization, or API performance improvements.
---

# Performance Pass

Run these steps in order. At the end, produce the **Summary report** (see below).

## 1. Review slow endpoints and add indexes

- Identify list/detail endpoints that filter or sort by non-primary-key columns (e.g. `dealership_id`, `status`, `createdAt`, `name`).
- Check the DB layer and Prisma schema for existing indexes on those columns and composite keys used in `where`/`orderBy`.
- Add indexes for:
  - Foreign keys and tenant columns (e.g. `dealership_id`) if not already indexed.
  - Columns used in equality filters and sort.
  - Composite indexes for common filter+sort combinations (e.g. `(dealership_id, status, createdAt)`).
- Prefer indexes that match actual query patterns; avoid redundant indexes.

## 2. Eliminate N+1 queries

- Find routes that return lists or nested data and trace to DB/service calls.
- For each list or nested load, ensure a single query with `include` or `select` instead of per-item queries.
- Use Prisma `include` for needed relations; use `select` to limit nested fields and avoid over-fetching.
- If raw SQL or query builders are used, batch related data (e.g. load all related in one query keyed by parent id).

## 3. Add caching where safe (server-side)

- Prefer caching for: reference/lookup data, tenant-scoped config, or expensive reads that are not user-specific or time-critical.
- Do **not** cache: per-request user data, finance/payment data, or responses that must be strictly real-time unless TTL is very short and invalidation is defined.
- Use in-memory or Redis with a short TTL; document cache keys and invalidation (e.g. on create/update/delete).
- Ensure cached responses are tenant-scoped (e.g. cache key includes `dealership_id`).

## 4. Reduce payload sizes

- For list and detail endpoints, use `select` (and nested `select`/`include`) so only needed fields are returned.
- Avoid returning large blobs, full audit trails, or unbounded nested lists in default responses.
- Keep list items lean; offer optional query params or separate endpoints for full detail if needed.

## 5. List endpoints: defaults and max limits

- Confirm every list endpoint uses pagination (limit/offset or cursor) per project rules.
- Enforce a **max limit** (e.g. 100) and a **sane default** (e.g. 20).
- Validate `limit`/`offset` (or cursor params) at the edge (e.g. Zod) so invalid values are rejected.

---

## Summary report (required output)

After the pass, output a short report in this form:

```markdown
## Performance Pass Summary

### Indexes added
- [Table / query]: [index description]

### N+1 fixes
- [Endpoint or service]: [what was changed]

### Caching added
- [Scope/key]: [what is cached, TTL, invalidation]

### Payload reductions
- [Endpoint]: [fields removed or limited]

### List endpoint limits
- [Endpoint]: default limit X, max limit Y (or confirmed already correct)

### Endpoints improved
- [Method and path]: [brief note]
```

List every endpoint that was modified or verified so the user can see what improved.
