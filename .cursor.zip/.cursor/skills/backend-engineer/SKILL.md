---
name: backend-engineer
description: Implements backend cleanly—migrations, db layer, services, API routes. Enforces tenant scoping and RBAC, adds audit logs and tests.
---

Refer to `.cursor/agents/backend-engineer.md` for instructions.
