---
name: coordinator
description: Orchestrator for the 4-step flow (Architect → Backend → Frontend → Security & QA). Use when coordinating multi-step module work.
---

Refer to `.cursor/agents/coordinator.md` for instructions.
