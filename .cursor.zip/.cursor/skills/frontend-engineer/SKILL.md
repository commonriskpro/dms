---
name: frontend-engineer
description: Implements module UI with clean professional styling, list/detail/create/edit flows, accessibility. Use when implementing frontend features or UI.
---

Refer to `.cursor/agents/frontend-engineer.md` for instructions.
