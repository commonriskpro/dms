---
name: scaffold-module-spec-build
description: Scaffolds a backend module from a spec: Prisma models, db layer, service layer, routes, audit logging, and tests. Use when scaffolding a new module from a specification, when the user says "scaffold module", "spec to build", or "build from spec", and when a file list and manual test checklist are required.
---

# Scaffold Module (Spec → Build)

Turn a module **specification** into a full backend build. Follow steps in order. Respect DMS non-negotiables: multi-tenant (`dealership_id`), RBAC on every route, Zod at the edge, pagination on lists, audit on create/update/delete and sensitive reads. No TODOs or placeholders.

**Deliverables**: Always return (1) a **file list** of created/updated files and (2) a **manual test checklist**.

---

## 0. Parse the spec

- Identify **resources** (entities/tables), **actions** (CRUD or domain ops), and **permissions** (who can do what).
- Confirm any constraints (no SSN/DOB, no raw card data, pagination required).
- If the spec is vague, infer minimal viable shape; do not guess sensitive fields.

---

## 1. Prisma models + indexes + constraints

- Add or extend schema (e.g. `prisma/schema.prisma` or under `modules/<name>/db`). Every business table **must** have `dealership_id` (UUID).
- **Indexes**: `@@index([dealership_id])`; composite for common filters (e.g. `@@index([dealership_id, status])`, `@@index([dealership_id, created_at])`); unique scoped by tenant where needed: `@@unique([dealership_id, external_id])`.
- Add foreign keys and constraints per spec. No raw card data; no SSN/DOB unless explicitly approved.

---

## 2. DB layer (scoped by dealership_id)

- Place under `modules/<module>/db`. All data access here; no raw Prisma in routes or services.
- Every function accepts `dealershipId` and uses it in every `where` clause. Never return or update another tenant's rows.
- Export: `getById`, `list` (limit/offset or cursor), `create`, `update`, `delete` (or soft-delete) as needed. Use transactions for multi-step writes.

---

## 3. Service layer (transactions + RBAC)

- Place under `modules/<module>/service`. Services call db layer only; no direct Prisma.
- Use transactions for any multi-table or multi-step operation.
- **RBAC**: Before create/update/delete and sensitive reads, check permission. Deny by default; no admin bypass unless required. Least privilege.
- Services accept `dealershipId`, `userId` (and optionally `role`/permissions) for scoping and audit.

---

## 4. Route handlers + Zod validation

- Place under `app/api/**`. Handlers are thin: validate → call service → respond.
- Validate **all** inputs with Zod at the edge: query, params, body. No unvalidated data to services. Error shape: `{ error: { code, message, details? } }`.
- Resolve `dealership_id` from auth/context; pass to service. Paginate all list endpoints (limit/offset or cursor).

---

## 5. Audit log (create/update/delete + sensitive reads)

- Write to the project audit mechanism for:
  - Create, update, delete on all critical resources
  - Sensitive reads where required (finance, customers, users/roles, documents)
- Record: who (user/id), what (resource/action), when (timestamp), tenant (`dealership_id`). Append-only; no updates or deletes of audit records.

---

## 6. Tests (tenant isolation + RBAC negative + core logic)

- Place under `modules/<module>/tests`.
- **Tenant isolation**: Assert dealership A never sees or changes dealership B data (get/list/update/delete with wrong tenant).
- **RBAC negative**: Assert unauthorized roles get denied; at least one denied case per protected action.
- **Core business logic**: Positive cases for main flows (create, update, list with filters, delete). Deterministic, fast.

---

## Completion: file list + manual test checklist

After implementing, **always** provide:

**File list**  
List every file created or updated (schema, db layer, service, routes, tests, shared types or Zod schemas).

**Manual test checklist**  
Short, actionable steps for a human (e.g. “As role X, create resource and confirm it appears only for same dealership”, “As role Y, attempt create and confirm 403”, “Verify audit log entry for delete”). Include at least one tenant-isolation check and one RBAC check.
