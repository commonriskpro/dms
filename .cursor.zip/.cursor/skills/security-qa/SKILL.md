---
name: security-qa
description: Security & QA. Finds and fixes tenant/RBAC leaks, adds RBAC and tenant-isolation tests. Use when running security audit or QA hardening.
---

Refer to `.cursor/agents/security-qa.md` for instructions.
