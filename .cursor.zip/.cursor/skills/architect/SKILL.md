---
name: architect
description: Schema, contracts, and module boundaries. Use when designing a new module, defining API contracts, Prisma schema, RBAC matrix, or events.
---

Refer to `.cursor/agents/architect.md` for instructions.
