---
name: qa-hardening
description: Runs QA and hardening for DMS: tenant isolation and RBAC tests, regression tests, PII checks, pagination verification, file upload validation, and rate limiting. Use when hardening a module, running a security audit, before release, or when the user asks for QA checklist, hardening, or regression tests.
---

# QA & Hardening

Run this workflow when hardening a module or doing a security/QA pass. Follow project rules in `.cursor/rules/DMS-Non-Negotiables.mdc`.

## Workflow

1. **Tenant isolation and RBAC**
   - Identify all routes and DB access for the module.
   - For each list/get/update/delete: ensure `dealership_id` is taken from auth/session and used in every query; no cross-tenant data leak.
   - For each route: ensure a permission check runs before business logic; no admin bypass unless documented.
   - Write or extend tests: (a) request with different `dealership_id` returns 403 or empty; (b) request without required permission returns 403.

2. **Regression tests for key flows**
   - List critical user flows (e.g. create deal, submit to lender, upload document).
   - Add or extend integration/e2e tests that exercise these flows end-to-end with valid data.
   - Ensure tests use a test tenant and cleanup.

3. **PII in logs and API responses**
   - Search for `console.log`, `logger.*`, and response serialization in the module.
   - Ensure no SSN, DOB, full name, email, phone, or income in logs or in API response bodies unless explicitly required and documented.
   - Redact or remove any PII found; use structured logs without PII.

4. **Pagination**
   - Find every list endpoint (e.g. GET that returns arrays of entities).
   - Ensure each accepts `limit` and `offset` (or cursor) and returns a bounded list plus total/cursor; no unbounded `.findMany()` without pagination.
   - Add or extend tests that assert pagination params are applied and max page size is enforced.

5. **File upload validation and signed URLs**
   - Find upload endpoints and any code that generates URLs to stored files.
   - Validate: file type allowlist, max size, and optionally malware scan; reject invalid uploads with 400.
   - Ensure download/preview uses short-lived signed URLs (or equivalent) and never exposes raw storage paths; verify URLs are scoped to tenant and permission.

6. **Rate limiting**
   - Identify auth endpoints (login, token refresh, password reset) and sensitive endpoints (e.g. finance, customer PII, user/role changes, document access).
   - Verify rate limiting is applied (e.g. per IP or per user) with sensible limits; add middleware or config if missing.
   - Add a test or manual check that excess requests return 429.

## Output: QA Checklist + What Was Fixed

After running the workflow, always produce two artifacts.

**1. QA checklist** (copy and fill; use `[x]` for done, `[ ]` for N/A or skipped):

```markdown
## QA Checklist — [Module or Scope]

### Tenant isolation & RBAC
- [ ] All routes scoped by dealership_id
- [ ] Permission enforced on every route
- [ ] Tests: tenant isolation + RBAC

### Regression
- [ ] Key flows have regression tests

### PII
- [ ] No PII in logs
- [ ] No PII in API responses (unless required)

### Pagination
- [ ] All list endpoints paginate
- [ ] Tests for pagination

### File upload & URLs
- [ ] Upload: type/size validated
- [ ] Download: signed URLs, tenant-scoped

### Rate limiting
- [ ] Auth endpoints rate limited
- [ ] Sensitive endpoints rate limited
```

**2. What was fixed** (short list):

```markdown
## What was fixed

- [Brief item 1]
- [Brief item 2]
- …
```

If nothing was changed, say "No code changes; checklist only" and still output the checklist with current status.
