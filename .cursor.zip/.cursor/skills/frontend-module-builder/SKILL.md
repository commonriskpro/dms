---
name: frontend-module-builder
description: Builds frontend modules with list pages (filters, pagination, sorting), detail pages with tabs, create/edit forms with validation, and accessible UI. Use when building a new frontend module, adding list/detail/forms for a resource, or when the user asks for frontend module build steps, list page, detail page, or form screens.
---

# Frontend Module Builder

Step-by-step guide to build a frontend module in the DMS. Follow in order. Comply with DMS rules: folder structure `modules/<name>/ui`, shared components under `components/**`, TypeScript strict, no duplicate components. No TODOs or placeholders.

**Deliverables**: Always return (1) a **file list** of created/updated files and (2) a **manual test checklist**.

---

## 1. List page (filters + pagination + sorting)

- Place under `modules/<module>/ui/` (e.g. `ListPage.tsx` or `*List*.tsx`). Route/entry as per app routing.
- **Filters**: Use shared filter components from `components/**`. Persist filter state in URL (query params) where appropriate so views are shareable and back/forward work.
- **Pagination**: Consume paginated API (limit/offset or cursor). Use shared `Pagination` (or equivalent) from `components/**`. Display page size selector if supported by API.
- **Sorting**: Sort controls for columns that the API supports; sync sort key and direction with API params (and optionally URL).
- **Data**: Fetch via existing API client or data layer; handle loading and errors (see §4). No direct Prisma or backend calls from UI.
- **Table/grid**: Use shared table/list components. Include accessible column headers and row semantics (e.g. `scope="col"`, proper labels).

---

## 2. Detail page (tabs where needed)

- Place under `modules/<module>/ui/` (e.g. `DetailPage.tsx` or `*Detail*.tsx`). Load single resource by id from route params; scope by tenant as per API.
- **Tabs**: Use when the detail has distinct sections (e.g. Overview, History, Documents). Use shared tab component from `components/**`. Ensure tab list and panels have correct roles and `aria` attributes; one tab panel visible at a time.
- **Content**: One primary section (e.g. overview) plus tabbed sections. Avoid duplicate components: reuse shared cards, description lists, and buttons from `components/**`.
- **Actions**: Edit/Delete etc. as buttons or links; wire to existing APIs and permission checks. Disable or hide actions the user is not allowed to perform.

---

## 3. Create / Edit forms (validation)

- Place under `modules/<module>/ui/` (e.g. `CreateForm.tsx`, `EditForm.tsx` or shared `*Form.tsx`). Reuse a single form component with create vs edit mode when possible.
- **Validation**: Validate on submit and optionally on blur/change. Use the same validation rules as the API (e.g. Zod-derived or shared schema). Show field-level errors and a summary (e.g. at top or near submit).
- **Fields**: Use shared form components (inputs, selects, date pickers, etc.) from `components/**`. Every input must have a visible or accessible label (`<label>` or `aria-label` / `aria-labelledby`).
- **Submit**: Call create/update API; on success navigate or refresh detail; on error show API error in consistent error shape (`{ error: { code, message, details? } }`). Disable submit while pending to avoid double submit.

---

## 4. Empty / loading / error states and styling

- **Empty**: When list has zero results (and no error), show a clear empty state (shared component if available): message and primary action (e.g. “Create first X”).
- **Loading**: Show loading state for list, detail, and forms (skeletons or spinners from `components/**`). Avoid layout shift where possible.
- **Error**: Show error state (shared component if available) with message and retry or navigation. Do not leave the user on a blank or broken view.
- **Styling**: Use design tokens and shared components so styling is consistent across the app. No one-off colors or spacing that conflict with the design system.

---

## 5. Keyboard navigation and accessible labels

- **Keyboard**: List and detail pages must be navigable with keyboard (Tab, Enter, Space). Tables: focus management and arrow keys if the shared table supports it. Modals and dialogs: trap focus and restore on close.
- **Labels**: Every interactive control has an accessible name (visible label or `aria-label`). Icons that act as buttons have `aria-label` or `title`. Headings form a logical outline (e.g. one `h1` per page).
- **Focus**: Visible focus indicators on all focusable elements. After create/edit success, move focus appropriately (e.g. to new record or success message).

---

## 6. Reuse shared UI components

- Do not duplicate: tables, pagination, filters, tabs, buttons, form inputs, cards, empty/loading/error states, modals. Implement or extend in `components/**` and use from `modules/<module>/ui/**`.
- If a shared component does not exist, add it under `components/**` and use it in the module. Prefer composition over copying markup or styles.

---

## Completion: file list + manual test checklist

After implementing, always provide:

**File list**  
List every file created or updated under `modules/<module>/ui/**`, `components/**`, and any new routes or types used by the frontend module.

**Manual test checklist**  
Short, actionable steps for a human tester, for example:

- List: “Open list page, apply filter X, change sort, change page; confirm URL and results match.”
- List: “Empty state: clear filters so no results; confirm empty message and CTA.”
- Detail: “Open detail, switch tabs; confirm only one panel visible and focus/keyboard work.”
- Form: “Submit create form with invalid data; confirm validation messages. Submit valid data; confirm redirect and new record appears.”
- Form: “Submit edit form; confirm success and updated data on detail.”
- A11y: “Tab through list and detail; confirm focus visible and no traps. Screen reader: confirm labels and headings.”
- Permissions: “As role without create permission, confirm create button hidden or disabled and cannot submit.”
